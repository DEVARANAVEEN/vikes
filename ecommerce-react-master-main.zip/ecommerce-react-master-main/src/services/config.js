const firebaseConfig = {
  apiKey: "AIzaSyBml6CZ8xVeWN71MOLNTf_yYAYHo25RVfM",
  authDomain: "ametouche-ed07c.firebaseapp.com",
  projectId: "ametouche-ed07c",
  storageBucket: "ametouche-ed07c.appspot.com",
  messagingSenderId: "798144822351",
  appId: "1:798144822351:web:198a455acf56946cdcfe3a",
  measurementId: "G-L9ZL4EXXQ2"
};

export default firebaseConfig;
